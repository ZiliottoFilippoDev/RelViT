from pytorch_lightning.callbacks import ModelCheckpoint
from pytorch_lightning.loggers import WandbLogger
from pytorch_lightning.callbacks import LearningRateMonitor
from pytorch_lightning.callbacks import Callback
from objectdetector import ObjectDetector
import pytorch_lightning as pl
import wandb
import argparse
import os

parser = argparse.ArgumentParser()
parser.add_argument('--epochs', type=int, default=20)
parser.add_argument('--lr', type=float, default=5e-4)
parser.add_argument('--tmax_lr', type=int, default=10)
parser.add_argument('--weight_decay', type=float, default=1e-4)
parser.add_argument('--version', type=str, default='1.0')
parser.add_argument('--pl_dir', type=str, default='Pl_checkpoints')
parser.add_argument('--batch_size_train', type=int, default=128)
parser.add_argument('--batch_size_val', type=int, default=8)
parser.add_argument('--num_workers', type=int, default=8)
parser.add_argument('--pretrained', type=bool, default=False)
parser.add_argument('--name', type=str, default='FasterViT')
parser.add_argument('--only_use_val', type=bool, default=True)
args = parser.parse_args()


lr_monitor = LearningRateMonitor(logging_interval='step')
detector = ObjectDetector(num_classes=91,
                          lr=args.lr,
                          weight_decay=args.weight_decay,
                          t_max=args.tmax_lr,
                          batch_train = args.batch_size_train,
                          batch_val = args.batch_size_val,
                          num_workers = args.num_workers,
                          pretrained = args.pretrained,
                          only_use_val = args.only_use_val)

#wandb_logger = WandbLogger(project=args.name, name=args.version,
#                           save_dir='ViTFasterRCNN',log_model=True)

trainer = pl.Trainer(accelerator="auto", max_epochs=args.epochs,
                    default_root_dir=args.pl_dir,
                    #logger=wandb_logger,
                    callbacks=[lr_monitor] ,
                     )

trainer.fit(detector)
#wandb.finish()