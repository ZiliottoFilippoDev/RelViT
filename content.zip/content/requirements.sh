pip install albumentations
pip install wget
pip install pycocotools
pip install zipfile36
pip install pytorch_lightning
pip install --upgrade wandb
pip install torchmetrics
pip install torchinfo
pip install argparse
pip3 install urllib3