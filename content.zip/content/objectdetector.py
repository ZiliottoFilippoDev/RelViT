import pytorch_lightning as pl
from torchmetrics.detection.mean_ap import MeanAveragePrecision
from torch.utils.data import random_split, DataLoader
from torchmetrics import Accuracy
import torch
import wandb
from maskrcnn import create_model
from datasets.coco_utils import get_coco
from datasets.presets import DetectionPresetEval, DetectionPresetTrain

def collate_fn(batch):
    return tuple(zip(*batch))

class ObjectDetector(pl.LightningModule):
    def __init__(self, num_classes, lr=0.0001, weight_decay=0.0005, t_max=10,
                  batch_train = 128, batch_val = 8, num_workers = 2, pretrained=False,
                  only_use_val = True):
        super().__init__()
        self.model = create_model(num_classes=num_classes, pretrained=pretrained)
        self.lr = lr
        self.weight_decay = weight_decay
        self.map_box = MeanAveragePrecision(box_format="xyxy", iou_type="bbox", compute_on_cpu=False)
        self.map_mask = MeanAveragePrecision(iou_type="segm")
        self.batch_train = batch_train
        self.batch_val = batch_val
        self.t_max = t_max
        self.num_workers = num_workers
        self.only_use_val = only_use_val
        self.save_hyperparameters()

    def forward(self, x):
        return self.model.forward(x)

    def training_step(self, batch, batch_idx):
        self.model.train(True)

        images  = list(image for image in batch[0])
        targets = [{k:v for k, v in t.items()} for t in batch[1]]

        loss_dict = self.model(images, targets)

        loss_cls = loss_dict['loss_classifier']
        loss_box_reg = loss_dict['loss_box_reg']
        loss_obj = loss_dict['loss_objectness']
        losses = sum(loss for loss in loss_dict.values())

        self.log('train_loss', losses, on_step=True, on_epoch=True, prog_bar=True, logger=True, batch_size = self.batch_train)
        self.log('train_loss_cls', loss_cls, on_step=True, on_epoch=True, batch_size = self.batch_train)
        self.log('train_loss_box_reg', loss_box_reg, on_step=True, on_epoch=True, batch_size = self.batch_train)
        self.log('train_loss_obj', loss_obj, on_step=True, on_epoch=True, batch_size = self.batch_train) 

        return losses

    def validation_step(self, batch, batch_idx):

        images  = list(image for image in batch[0])
        targets = [{k:v for k, v in t.items()} for t in batch[1]]
         
        preds = self.model(images)
        preds = [{k:v for k, v in t.items()} for t in preds]

        for i in range(len(preds)):
          preds[i]['masks'] = preds[i]['masks'] > 0.5
          preds[i]['masks'] = preds[i]['masks'].to(torch.uint8).squeeze(1)
        
        self.map_mask.update(preds=preds, target=targets)
        self.map_box.update(preds=preds, target=targets)

    def validation_epoch_end(self, validation_step_outputs):
        mAPs_box = {"val_box_" + k: v for k, v in self.map_box.compute().items()}     
        mAPs_mask = {"val_mask_" + k: v for k, v in self.map_mask.compute().items()}     

        self.print(mAPs_box)
        self.print(mAPs_mask)
        self.log_dict(mAPs_box)
        self.log_dict(mAPs_mask)
        self.map_box.reset()
        self.map_mask.reset()

    def configure_optimizers(self):
        params = [p for p in self.model.parameters() if p.requires_grad]
        optimizer = torch.optim.SGD(self.model.parameters(), lr=self.lr, momentum=0.9, weight_decay=self.weight_decay)
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=self.t_max, eta_min=5e-4)

        return {"optimizer":optimizer, "lr_scheduler": sch}

    def configure_optimizers(self):
        params = [p for p in self.model.parameters() if p.requires_grad]
        optimizer = torch.optim.SGD(self.model.parameters(), lr=self.lr, momentum=0.9, weight_decay=self.weight_decay)
        sch = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=self.t_max, eta_min=5e-4)

        return {"optimizer":optimizer, "lr_scheduler": sch}

    ####################
    # DATA RELATED HOOKS
    ####################   

    def prepare_data(self):
      tform_val = DetectionPresetEval(resize=224)
      tform_train = DetectionPresetTrain(data_augmentation='hflip', resize=224)

      if self.only_use_val:
          self.trainset = get_coco(root='datasets/data', image_set='val', transforms = tform_train)
      else:
          self.trainset = get_coco(root='datasets/data', split='train', transforms=tform_train)
      self.valset = get_coco(root='datasets/data', image_set='val', transforms = tform_train)

      #### PROVA #####
      self.trainset = torch.utils.data.Subset(self.trainset, [i for i in range(self.batch_train)])
      self.valset = torch.utils.data.Subset(self.valset, [i for i in range(self.batch_val)])

    def train_dataloader(self):
        return DataLoader(self.trainset, shuffle=True, batch_size=self.batch_train, num_workers=self.num_workers,
                          collate_fn=collate_fn)

    def val_dataloader(self):
        return DataLoader(self.valset, shuffle=False, batch_size=self.batch_val, num_workers=self.num_workers,
                          collate_fn=collate_fn)

                        