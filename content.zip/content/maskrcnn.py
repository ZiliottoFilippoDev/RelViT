from torchvision.models.detection import FasterRCNN, MaskRCNN
from torchvision.models.detection.rpn import AnchorGenerator
from torchvision.ops import MultiScaleRoIAlign
import models.vit_dino as vit_dino
import torchvision
import torch
import torch.nn as nn

class ModifyViT(nn.Module):
    def __init__(self, num_classes=91, pretrained=False):
        super(ModifyViT, self).__init__()
        self.model = vit_dino.__dict__['vit_tiny'](num_classes=num_classes, use_clf_token=True,
                                                     use_positional_embeddings=True)
        self.patch_size = 16 // 2

        if pretrained:
            self.model.load_state_dict(torch.load('vit_tiny.pth'))

    def forward(self, x):
        out = self.model(x)
        x = out['z_patches']
        x = x.reshape(x.shape[0], -1, self.patch_size, self.patch_size)
        return x


def create_model(num_classes = 91, pretrained = False, min_size = 200, max_size = 1300):

    backbone = ModifyViT(num_classes = num_classes)
    backbone.out_channels = 588

    anchorgen = AnchorGenerator(sizes=((32, 64, 128, 256),),
                                            aspect_ratios=((0.5, 1.0, 2.0),))
    pooler = MultiScaleRoIAlign(featmap_names=['0'], output_size=4, sampling_ratio=2)
    mask_roi_pooler = MultiScaleRoIAlign(featmap_names=['0'], output_size=4,sampling_ratio=2)      

    model = MaskRCNN(backbone=backbone, min_size=min_size, max_size=max_size,
                                num_classes=num_classes,
                                rpn_anchor_generator=anchorgen, box_roi_pool=pooler,
                                mask_roi_pool=mask_roi_pooler)

    if pretrained:
        model = torchvision.models.detection.maskrcnn_resnet50_fpn(num_classes=num_classes,pretrained=True)
    return model